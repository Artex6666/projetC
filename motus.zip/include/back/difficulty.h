#ifndef DIFFICULTY_H
#define DIFFICULTY_H

int calculate_difficulty(const char* word);
void toUpperCase(const char* input, char* output, int max_length);

#endif