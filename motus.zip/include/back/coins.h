#ifndef COINS_H
#define COINS_H

int getUsersCoin(void);
void addUsersCoin(int pieces);

#endif